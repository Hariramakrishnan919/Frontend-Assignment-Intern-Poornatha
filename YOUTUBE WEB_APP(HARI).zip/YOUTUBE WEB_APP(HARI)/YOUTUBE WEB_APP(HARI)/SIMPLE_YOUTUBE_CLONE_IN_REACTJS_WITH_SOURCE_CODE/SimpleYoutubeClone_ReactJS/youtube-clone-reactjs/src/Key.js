const API_KEY = 'AIzaSyD_27wzWJEHhX5J35Lj_PLicGBf1d75xvQ'; //provide your own youtube api(This my API created for my project) 

module.exports = API_KEY; 